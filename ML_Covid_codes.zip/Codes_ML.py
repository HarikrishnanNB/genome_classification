"""
This module does hyperparameter tuning for the Neurochaos-SVM method.
This module finds the best epsilon and discrimnation threshold for a given
intial neural activicty. The hyperparameters are saved as the program completes
its execution.

Author: Harikrishnan N B
Email: harikrishnannb07@gmail.com
Dtd: 31 - July - 2020
"""



import os
import numpy as np
import pandas as pd
from sklearn.model_selection import KFold
from sklearn.metrics import f1_score, accuracy_score
from sklearn.naive_bayes import GaussianNB
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import StratifiedKFold
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix as cm
from sklearn.metrics import classification_report
import ChaosFEX.feature_extractor as CFX
from load_data import get_data



def classification_report_csv_(report, num_classes):
    """
    This module returns the classfication metric for binary classification and
    five class classification as a dataframe. The module currently works for
    binary and five class classification.
    Parameters
    ----------
    report : classification metric report
        DESCRIPTION - Contains the precision recall f1score
    num_classes : int
        DESCRIPTION - 2 or 5, if 2 the report for binary class is returned
        if 5 the report for 5 class classification is returned.
    Returns
    -------
    dataframe - contains precision recall f1score

    """
    if num_classes == 2:
        report_data = []
        lines = report.split('\n')
        report_data.append(lines[0])
        report_data.append(lines[2])
        report_data.append(lines[3])
        report_data.append(lines[5])
        report_data.append(lines[6])
        report_data.append(lines[7])
        dataframe = pd.DataFrame.from_dict(report_data)
    #    dataframe.to_csv('report.csv', index = False)
        return dataframe
    elif num_classes == 5:
        report_data = []
        lines = report.split('\n')
        report_data.append(lines[0])
        report_data.append(lines[2])
        report_data.append(lines[3])
        report_data.append(lines[4])
        report_data.append(lines[5])
        report_data.append(lines[6])
        report_data.append(lines[8])
        report_data.append(lines[9])
        report_data.append(lines[10])
        dataframe = pd.DataFrame.from_dict(report_data)
    #    dataframe.to_csv('report.csv', index = False)
        return dataframe


def five_fold_validation(classification_type, method_name, target_names):
    """
    This module does the five_fold_crossvalidation and saves the classifcation
    report. At present the results for binary classification and five class classification is saved.
    Author: Harikrishnan N B
    Email: harikrishnannb07@gmail.com
    Dtd: 2 - August - 2020

    Parameters
    ----------
    classification_type : string
        DESCRIPTION - classification_type == "binary_class" loads binary classification genome data.
        classification_type == "multi_class" loads multiclass genome data
    epsilon : scalar, float
        DESCRIPTION - A value in the range 0 and 0.3. for eg. epsilon = 0.1835
    initial_neural_activity : scalar, float
        DESCRIPTION - The chaotic neurons has an initial neural activity.
        Initial neural activity is a value in the range 0 and 1.
    discrimination_threshold : scalar, float
        DESCRIPTION - The chaotic neurons has a discrimination threhold.
        discrimination threshold is a value in the range 0 and 1.
    method_name : string
        DESCRIPTION -     DESCRIPTION - method_name can take the following arguments
        random_forest, knn, logistic_regression, naive_bayes
    target_names : array, 1D, string
        DESCRIPTION - if there are two classes, then target_names = ['class-0', class-1]
        Note- At the present version of the code, the results for binary classification
        and five class classification will be saved.
    Returns
    -------
    mean_fold_accuracy_, mean_fold_fscore_, mean_fold_accuracy_svm, mean_fold_fscore_svm

    The above are the average accuracy and f1 score for the five fold validation for ml algorithms.
    """

    path = os.getcwd()
    result_path = path + '/ML-RESULTS/five_fold_cv/' + method_name + '/'  + classification_type +'/' 
    

    # Creating Folder to save the results
    try:
        os.makedirs(result_path)
    except OSError:
        print("Creation of the result directory %s failed" % result_path)
    else:
        print("Successfully created the result directory %s" % result_path)

    

    full_genome_data, full_genome_label = get_data(classification_type)

    num_classes = len(np.unique(full_genome_label)) # Number of classes
    print("**** Genome data details ******")
    for class_label in range(np.max(full_genome_label)+1):
        print("Total Data instance in Class -", class_label, " = ", full_genome_label.tolist().count([class_label]))

    # Stratified five fold cross validation.
    stratified_k_fold = StratifiedKFold(n_splits=5, random_state=42, shuffle=True) # Define the split - into 5 folds
    stratified_k_fold.get_n_splits(full_genome_data, full_genome_label) # returns the number of splitting iterations in the cross-validator

    print(stratified_k_fold)
    StratifiedKFold(n_splits=5, random_state=42, shuffle=True)

    iterations = 0

    acc_temp_ = []
    fscore_temp_ = []

  

    for train_index, val_index in stratified_k_fold.split(full_genome_data, full_genome_label):

        iterations = iterations+1

        print("iterations = ", iterations)

        # Spliting into training and validation
        train_genome_data, val_genome_data = full_genome_data[train_index], full_genome_data[val_index]
        train_genome_label, val_genome_label = full_genome_label[train_index], full_genome_label[val_index]


        print(" train data (%) = ", (train_genome_data.shape[0]/full_genome_data.shape[0])*100)
        print("val data (%) = ", (val_genome_data.shape[0]/full_genome_data.shape[0])*100)

        
        # Different Classifiers
        if method_name == "random_forest":
            classifier_ = RandomForestClassifier(max_depth=2, max_features="auto", class_weight="balanced", random_state=0)
        elif method_name == "knn":
            classifier_ = KNeighborsClassifier(n_neighbors=1)
        elif method_name == "logistic_regression":
            classifier_ = LogisticRegression(dual=False, penalty="l2", solver="liblinear", random_state=0)
        elif method_name == "naive_bayes":
            classifier_ = GaussianNB()

        classifier_.fit(train_genome_data, train_genome_label[:, 0])
        predicted_val_label = classifier_.predict(val_genome_data)

        acc_ = accuracy_score(val_genome_label, predicted_val_label)*100
        f1score_ = f1_score(val_genome_label, predicted_val_label, average="macro")
        report_ = classification_report(val_genome_label, predicted_val_label, target_names=target_names)

        # Saving the classification report to csv file for  classifier.
        print(report_)
        if num_classes == 2:
            classification_report_csv_(report_, num_classes).to_csv(result_path+ method_name +'_' + str(iterations) +'.csv', index=False)
        elif num_classes == 5:
            classification_report_csv_(report_, num_classes).to_csv(result_path+ method_name +'_'+ str(iterations) +'.csv', index=False)
        else:
            print("could not save classfication results-the current code saves the result of 2 class and 5 class problems")

        confusion_matrix_ = cm(val_genome_label, predicted_val_label)
        print("Confusion matrix for " + method_name + "\n", confusion_matrix_)

        acc_temp_.append(acc_)
        fscore_temp_.append(f1score_)

        
        

   
    mean_fold_accuracy_ = np.mean(acc_temp_)
    mean_fold_fscore_ = np.mean(fscore_temp_)

    return mean_fold_accuracy_, mean_fold_fscore_, 






def low_training_sample_binary_class(classification_type, trials, max_samples, method_name):
    """

    This is the module for the low training sample regime for binary
    classification dataset.

    Parameters
    ----------
    classification_type : string
        DESCRIPTION - This code is only for binary classification,
        classification_type= "larger_binary_class"
    trials : int
        DESCRIPTION - The number of random trials of training. For eg. if trials = 20, we do
        20 random trails of training and find the macro averged f1-score of the test data for the 20 ransod trials.
    max_sample : int
        DESCRIPTION - The upper limit on the number of samples per class for training. For eg., if
        max_samples = 6, means the maximum number of samples per class used for training is 6.
    method_name : string
        DESCRIPTION - method_name can take the following arguments
        random_forest, knn, logistic_regression, naive_bayes
    Returns
    -------
    fscore_ : array, 2D, float
        DESCRIPTION. - The macro averged f1-score for training with 1, 2.., max_samples per class.
        This will provide averaged f1-score for N random trials of training with 1, 2,..., max_samples
        per class.
    standard_deviation_fscore_ : array, 2D, flaot
        DESCRIPTION - This will provide the standard deviation of averaged f1-score for N random trials of training with 1, 2,..., max_samples
        per class.
    
    """
    full_genome_data, full_genome_label = get_data(classification_type)
    # Indices of class-0 and class-1 data instances
    index_0 = np.where(full_genome_label == 0)[0]
    index_1 = np.where(full_genome_label == 1)[0]

    print("**** TOTAL_DATA ******")
    for class_label in range(np.max(full_genome_label)+1):
        print("Data instance in Class -", class_label, " = ", full_genome_label.tolist().count([class_label]))

   
    
    # Input data (without Neurochaos Feature Extraction)
    genome_data_0 = full_genome_data[index_0, :]
    genome_data_1 = full_genome_data[index_1, :]


    # Number of samples per class. For eg. if max_samples is 4, we compute
    # training with 1, 2 3 and 4 samples. Each of these training is done
    # with N random trials.
    samples_per_class = np.arange(1, max_samples + 1, 1)

    # Initialization of classification metrics
    accuracy_ = np.zeros((len(samples_per_class), 1))
    fscore_ = np.zeros((len(samples_per_class), 1))
    standard_deviation_fscore_ = np.zeros((len(samples_per_class), 1))



    for num_instance in samples_per_class:
        # Neurochaos array for appending accuracy and f1score
        accuracy_list = []
        f1score_list = []


        # We do N random trials of training
        for trial_number in range(0, trials):

           

            train_genome_data_0, test_genome_data_0, train_genome_label_0, test_genome_label_0 = train_test_split(genome_data_0, full_genome_label[index_0], test_size=1 - (num_instance/genome_data_0.shape[0]), random_state=trial_number)
            train_genome_data_1, test_genome_data_1, train_genome_label_1, test_genome_label_1 = train_test_split(genome_data_1, full_genome_label[index_1], test_size=1 - (num_instance/genome_data_1.shape[0]), random_state=trial_number)

            print("num of samples per class = ", num_instance, "trial number = ", trial_number)

            test_genome_data = np.vstack((test_genome_data_0, test_genome_data_1))
            test_genome_label = np.vstack((test_genome_label_0, test_genome_label_1))


            train_genome_data = np.vstack((train_genome_data_0, train_genome_data_1))
            train_genome_label = np.vstack((train_genome_label_0, train_genome_label_1))


        

            # Classifiers
            
            if method_name == "random_forest":
                classifier_ = RandomForestClassifier(max_depth=2, max_features="auto", class_weight="balanced", random_state=0)
            elif method_name == "knn":
                classifier_ = KNeighborsClassifier(n_neighbors=1)
            elif method_name == "logistic_regression":
                classifier_ = LogisticRegression(dual=False, penalty="l2", solver="liblinear", random_state=0)
            elif method_name == "naive_bayes":
                classifier_ = GaussianNB()
                
            classifier_.fit(train_genome_data, train_genome_label[:, 0])
            predicted_labels_ = classifier_.predict(test_genome_data)

            accuracy_val = accuracy_score(test_genome_label, predicted_labels_)*100

            f1score_val = f1_score(test_genome_label, predicted_labels_, average="macro")

            accuracy_list.append(accuracy_val)
            f1score_list.append(f1score_val)


            


        accuracy_[num_instance-1, 0] = np.mean(accuracy_list)
        fscore_[num_instance-1, 0] = np.mean(f1score_list)
        standard_deviation_fscore_[num_instance-1, 0] = np.std(f1score_list)


        
    print("Saving Results")

    path = os.getcwd()
    result_path = path + '/ML-LTS-RESULTS/'  + method_name +'/'+ classification_type + '/LTS/'


    try:
        os.makedirs(result_path)
    except OSError:
        print("Creation of the result directory %s failed" % result_path)
    else:
        print("Successfully created the result directory %s" % result_path)

    np.save(result_path+"/fscore_.npy", fscore_)
    np.save(result_path+"/std_fscore_.npy", standard_deviation_fscore_)
    np.save(result_path+"/samples_per_class.npy", samples_per_class)

    
    return fscore_, standard_deviation_fscore_ 


def low_training_sample_five_class(classification_type, trials, max_samples, method_name):
    """
    This is the function module for the low training sample regime for five class
    classification dataset. To add more classes or reduce the number of classes,
    the user has to modify this function file.

    Parameters
    ----------
    classification_type : string
        DESCRIPTION - This code is only for five class classification,
        classification_type= "multi_class"
    trials : int
        DESCRIPTION - The number of random trials of training. For eg. if trials = 20, we do
        20 random trails of training and find the macro averged f1-score of the test data for the 20 ransod trials.
    max_sample : int
        DESCRIPTION - The upper limit on the number of samples per class for training. For eg., if
        max_samples = 6, means the maximum number of samples per class used for training is 6.
    method_name : string
        DESCRIPTION - method_name can take the following arguments
        random_forest, knn, logistic_regression, naive_bayes

    Returns
    -------
    fscore_ : array, 2D, float
        DESCRIPTION. - The macro averged f1-score for training with 1, 2.., max_samples per class.
        This will provide averaged f1-score for N random trials of training with 1, 2,..., max_samples
        per class.
    standard_deviation_fscore_ : array, 2D, flaot
        DESCRIPTION - This will provide the standard deviation of averaged f1-score for N random trials of training with 1, 2,..., max_samples
        per class.
   

    """
    full_genome_data, full_genome_label = get_data(classification_type)
    # Indices of class-0 and class-1 data instances
    index_0 = np.where(full_genome_label == 0)[0]
    index_1 = np.where(full_genome_label == 1)[0]
    index_2 = np.where(full_genome_label == 2)[0]
    index_3 = np.where(full_genome_label == 3)[0]
    index_4 = np.where(full_genome_label == 4)[0]

    print("**** TOTAL_DATA ******")
    for class_label in range(np.max(full_genome_label)+1):
        print("Data instance in Class -", class_label, " = ", full_genome_label.tolist().count([class_label]))

    

    # Input data (without Neurochaos Feature Extraction)
    genome_data_0 = full_genome_data[index_0, :]
    genome_data_1 = full_genome_data[index_1, :]
    genome_data_2 = full_genome_data[index_2, :]
    genome_data_3 = full_genome_data[index_3, :]
    genome_data_4 = full_genome_data[index_4, :]

    # Number of samples per class. For eg. if max_samples is 4, we compute
    # training with 1, 2 3 and 4 samples. Each of these training is done
    # with N random trials.
    samples_per_class = np.arange(1, max_samples + 1, 1)

    # Initialization for Neurochaos
    accuracy_ = np.zeros((len(samples_per_class), 1))
    fscore_ = np.zeros((len(samples_per_class), 1))
    standard_deviation_fscore_ = np.zeros((len(samples_per_class), 1))

    
    for num_instance in samples_per_class:
        # Neurochaos array for appending accuracy and f1score
        accuracy_list = []
        f1score_list = []

        # We do N random trials of training
        for trial_number in range(0, trials):

            

            train_genome_data_0, test_genome_data_0, train_genome_label_0, test_genome_label_0 = train_test_split(genome_data_0, full_genome_label[index_0], test_size=1 - (num_instance/genome_data_0.shape[0]), random_state=trial_number)
            train_genome_data_1, test_genome_data_1, train_genome_label_1, test_genome_label_1 = train_test_split(genome_data_1, full_genome_label[index_1], test_size=1 - (num_instance/genome_data_1.shape[0]), random_state=trial_number)
            train_genome_data_2, test_genome_data_2, train_genome_label_2, test_genome_label_2 = train_test_split(genome_data_2, full_genome_label[index_2], test_size=1 - (num_instance/genome_data_2.shape[0]), random_state=trial_number)
            train_genome_data_3, test_genome_data_3, train_genome_label_3, test_genome_label_3 = train_test_split(genome_data_3, full_genome_label[index_3], test_size=1 - (num_instance/genome_data_3.shape[0]), random_state=trial_number)
            train_genome_data_4, test_genome_data_4, train_genome_label_4, test_genome_label_4 = train_test_split(genome_data_4, full_genome_label[index_4], test_size=1 - (num_instance/genome_data_4.shape[0]), random_state=trial_number)

            print("num of samples per class = ", num_instance, "trial number = ", trial_number)

            test_genome_data = np.concatenate((test_genome_data_0, test_genome_data_1, test_genome_data_2, test_genome_data_3, test_genome_data_4))
            test_genome_label = np.concatenate((test_genome_label_0, test_genome_label_1, test_genome_label_2, test_genome_label_3, test_genome_label_4))


            train_genome_data = np.concatenate((train_genome_data_0, train_genome_data_1, train_genome_data_2, train_genome_data_3, train_genome_data_4))
            train_genome_label = np.concatenate((train_genome_label_0, train_genome_label_1, train_genome_label_2, train_genome_label_3, train_genome_label_4))


             # Classifiers
            
            if method_name == "random_forest":
                classifier_ = RandomForestClassifier(max_depth=2, max_features="auto", class_weight="balanced", random_state=0)
            elif method_name == "knn":
                classifier_ = KNeighborsClassifier(n_neighbors=1)
            elif method_name == "logistic_regression":
                classifier_ = LogisticRegression(dual=False, penalty="l2", solver="liblinear", random_state=0)
            elif method_name == "naive_bayes":
                classifier_ = GaussianNB()
            
            classifier_.fit(train_genome_data, train_genome_label[:, 0])
            predicted_labels_ = classifier_.predict(test_genome_data)

            accuracy_val = accuracy_score(test_genome_label, predicted_labels_)*100

            f1score_val = f1_score(test_genome_label, predicted_labels_, average="macro")

            accuracy_list.append(accuracy_val)
            f1score_list.append(f1score_val)

        accuracy_[num_instance-1, 0] = np.mean(accuracy_list)
        fscore_[num_instance-1, 0] = np.mean(f1score_list)
        standard_deviation_fscore_[num_instance-1, 0] = np.std(f1score_list)


    print("Saving Results")

    path = os.getcwd()
    result_path = path + '/ML-LTS-RESULTS/' + method_name +'/' + classification_type + '/LTS/'


    try:
        os.makedirs(result_path)
    except OSError:
        print("Creation of the result directory %s failed" % result_path)
    else:
        print("Successfully created the result directory %s" % result_path)

    np.save(result_path+"/fscore_.npy", fscore_)
    np.save(result_path+"/std_fscore_.npy", standard_deviation_fscore_)
    np.save(result_path+"/samples_per_class.npy", samples_per_class)


    return fscore_, standard_deviation_fscore_