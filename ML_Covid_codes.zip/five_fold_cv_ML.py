"""
This is the executing file for the code of five fold validation for binary class, multiclass and
larger dataset. Go to five_fold_valifation.py in Codes.py to edit the function.

"""
from Codes_ML import five_fold_validation

METHOD_NAME = "knn"
CLASSIFICATION_TYPE = "multi_class"

if (CLASSIFICATION_TYPE == "binary_class" or CLASSIFICATION_TYPE == "larger_data_binary_class"):
    TARGET_NAMES = ['Class-0', 'Class-1']
elif CLASSIFICATION_TYPE == "multi_class":
    TARGET_NAMES = ['Class-0', 'Class-1', 'Class-2', 'Class-3', 'Class-4']

MEAN_FOLD_ACCURACY_, MEAN_FOLD_FSCORE_ = five_fold_validation(CLASSIFICATION_TYPE,  METHOD_NAME, TARGET_NAMES)

print("Average Fold accuracy neurochaos = ", MEAN_FOLD_ACCURACY_)
print("Average Fold f1score neurochaos = ", MEAN_FOLD_FSCORE_)

