# -*- coding: utf-8 -*-
"""
Created on Tue Sep  8 11:52:33 2020

@author: harik
"""
import os
import numpy as np
from sklearn.metrics import f1_score, accuracy_score
from sklearn.ensemble import RandomForestClassifier

from sklearn.model_selection import KFold
# from sklearn.model_selection import train_test_split
# from sklearn.metrics import confusion_matrix as cm
# from sklearn.metrics import classification_report
from load_data import get_data





classification_type = "binary_class"

max_depth1 = [2, 3, 4, 5, 6, 7, 8, 9, 10, 20, 30, 50]
max_features1 = ["auto", "sqrt", "log2"]
class_weight1 = ["balanced", "balanced_subsample"]



full_genome_data, full_genome_label = get_data(classification_type)
accuracy_matrix = np.zeros((len(max_depth1), len(max_features1), len(class_weight1)))
f1score_matrix = np.zeros((len(max_depth1), len(max_features1), len(class_weight1)))
hyperparameters_max_depth = np.zeros((len(max_depth1), len(max_features1), len(class_weight1)))
hyperparameters_max_features = np.zeros((len(max_depth1), len(max_features1), len(class_weight1)))
hyperparameters_class_weight = np.zeros((len(max_depth1), len(max_features1), len(class_weight1)))
   
k_fold = KFold(n_splits=5, random_state=42, shuffle=True)

# returns the number of splitting iterations in the cross-validator
k_fold.get_n_splits(full_genome_data)
print(k_fold)

KFold(n_splits=5, random_state=42, shuffle=True)
row = -1



for md in max_depth1:
   
    row = row+1
    col = -1
    width = -1

    for mf in max_features1:
        col = col+1
        width = -1
        for cw in class_weight1:
            width = width + 1
            acc_temp = []
            fscore_temp = []

            for train_index, val_index in k_fold.split(full_genome_data):

                train_genome_data = full_genome_data[train_index]
                val_genome_data = full_genome_data[val_index]
                train_genome_label = full_genome_label[train_index]
                val_genome_label = full_genome_label[val_index]
                print(" train data (%) = ",
                      (train_genome_data.shape[0]/full_genome_data.shape[0])*100)
                print("val data (%) = ",
                      (val_genome_data.shape[0]/full_genome_data.shape[0])*100)

            
            # Random Forest Classifier.

                classifier_random_forest = RandomForestClassifier(max_depth=md, max_features=mf, class_weight=cw, random_state=0)
                classifier_random_forest.fit(train_genome_data,
                                              train_genome_label[:, 0])
                predicted_val_label = classifier_random_forest.predict(val_genome_data)
            
            # Accuracy
                acc_random_forest = accuracy_score(val_genome_label, predicted_val_label)*100
            # Macro F1- Score
                f1score_random_forest = f1_score(val_genome_label, predicted_val_label, average="macro")

                acc_temp.append(acc_random_forest)
                fscore_temp.append(f1score_random_forest)

        
            # Average Accuracy
            accuracy_matrix[row, col, width] = np.mean(acc_temp)
            # Average Macro F1-score
            f1score_matrix[row, col, width] = np.mean(fscore_temp)
            
            hyperparameters_max_depth[row, col, width] = md
            hyperparameters_max_features[row, col, width] = max_features1.index(mf)
            hyperparameters_class_weight[row, col, width] = class_weight1.index(cw)

        print("Three fold Average F-SCORE %.3f" %f1score_matrix[row, col, width])

        print('--------------------------')
# Creating a result path to save the results.
path = os.getcwd()
result_path = path + '/RANDOM-FOREST-HYPERPARAMETER/'  + classification_type + '/CROSS_VALIDATION/'


try:
    os.makedirs(result_path)
except OSError:
    print("Creation of the result directory %s failed" % result_path)
else:
    print("Successfully created the result directory %s" % result_path)

print("Saving Hyperparameter Tuning Results")
np.save(result_path + 'H_ACCURACY.npy', accuracy_matrix)
np.save(result_path + 'H_FSCORE.npy', f1score_matrix)

# =============================================================================
# best hyperparameters
# =============================================================================
# Computing the maximum F1-score obtained during crossvalidation.
maximum_fscore = np.max(f1score_matrix)

best_max_depth = []
best_max_features = []
best_class_weight = []
for row in range(0, f1score_matrix.shape[0]):

    for col in range(0, f1score_matrix.shape[1]):
        
        for width in range(0, f1score_matrix.shape[2]):

            if f1score_matrix[row, col, width] == maximum_fscore:

                best_max_depth.append(hyperparameters_max_depth[row, col, width])
                best_max_features.append(max_features1[int(hyperparameters_max_features[row, col, width])])
                best_class_weight.append(class_weight1[int(hyperparameters_class_weight[row, col, width])])

print("maximum f1score_neurochaos = ", maximum_fscore)
print("best max depth = ", best_max_depth)
print("best max features = ", best_max_features)
print("best class weight = ", best_class_weight)
