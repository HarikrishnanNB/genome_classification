"""
This is the main file for low training sample regime for multiclass classification problem.
In this we use the larger binary classification data. In order edit the function file - go to Codes.py and edit the function low_training_sample_five_class


Author: Harikrishnan N B
Email: harikrishnannb07@gmail.com
"""
from Codes_ML import low_training_sample_five_class
CLASSIFICATION_TYPE = "multi_class"
TRIALS = 200
MAX_SAMPLES = 6
METHOD_NAME = "knn"


FSCORE_, STANDARD_DEVIATION_FSCORE_,  = low_training_sample_five_class(CLASSIFICATION_TYPE, TRIALS, MAX_SAMPLES, METHOD_NAME)

print("Average F1-score of " + METHOD_NAME  + " = " , FSCORE_)

