"""
This is the plotting file for the larger binary classification data.
Author: Harikrishnan N B
Email: harikrishnannb07@gmail.com
"""
import numpy as np
import os
import matplotlib.pyplot as plt

## PLOTING
DATA_NAME = "larger_binary_class"


PATH = os.getcwd()
RESULT_PATH = PATH + '/NEUROCHAOS-LTS-RESULTS/'  + DATA_NAME + '/LTS/'




FSCORE_NEUROCHAOS = np.load(RESULT_PATH+"/fscore_neurochaos.npy" )    
STD_FSCORE_NEUROCHAOS = np.load(RESULT_PATH+"/std_fscore_neurochaos.npy") 
 
FSCORE_SVM = np.load(RESULT_PATH+"/fscore_svm.npy" )    
STD_FSCORE_SVM = np.load(RESULT_PATH+"/std_fscore_svm.npy")   
SAMPLES_PER_CLASS = np.load(RESULT_PATH+"/samples_per_class.npy")


# Other classifiers

RESULT_PATH_KNN = PATH + '/ML-LTS-RESULTS/knn/'  + DATA_NAME + '/LTS/'
FSCORE_KNN = np.load(RESULT_PATH_KNN+"/fscore_.npy" )    
STD_FSCORE_KNN = np.load(RESULT_PATH_KNN+"/std_fscore_.npy")   


RESULT_PATH_LOGISTIC_REGRESSION = PATH + '/ML-LTS-RESULTS/logistic_regression/'  + DATA_NAME + '/LTS/'
FSCORE_LOGISTIC_REGRESSION = np.load(RESULT_PATH_LOGISTIC_REGRESSION+"/fscore_.npy" )    
STD_FSCORE_LOGISTIC_REGRESSION = np.load(RESULT_PATH_LOGISTIC_REGRESSION+"/std_fscore_.npy")  


RESULT_PATH_NAIVE_BAYES = PATH + '/ML-LTS-RESULTS/naive_bayes/'  + DATA_NAME + '/LTS/'
FSCORE_NAIVE_BAYES = np.load(RESULT_PATH_NAIVE_BAYES+"/fscore_.npy" )    
STD_FSCORE_NAIVE_BAYES = np.load(RESULT_PATH_NAIVE_BAYES+"/std_fscore_.npy")  


RESULT_PATH_RANDOM_FOREST = PATH + '/ML-LTS-RESULTS/random_forest/'  + DATA_NAME + '/LTS/'
FSCORE_RANDOM_FOREST= np.load(RESULT_PATH_RANDOM_FOREST+"/fscore_.npy" )    
STD_FSCORE_RANDOM_FOREST = np.load(RESULT_PATH_RANDOM_FOREST+"/std_fscore_.npy")  



# Plotting F1-score vs. Samples per class
plt.figure(figsize=(15,10))

plt.plot(SAMPLES_PER_CLASS ,FSCORE_NEUROCHAOS[:,0], linewidth = 3.0,  linestyle='solid', color ='r', marker='s',ms=15, label="ChaosFEX+SVM")
plt.plot(SAMPLES_PER_CLASS ,FSCORE_SVM[:,0], linewidth = 3.0, linestyle='--', color ='k', marker='o', ms=15, label="SVM (linear)")
plt.plot(SAMPLES_PER_CLASS ,FSCORE_KNN[:,0], linewidth = 3.0, linestyle='-', color ='g', marker='^', ms=15, label="KNN")
plt.plot(SAMPLES_PER_CLASS ,FSCORE_LOGISTIC_REGRESSION[:,0], linewidth = 3.0, linestyle='-', color ='b', marker='*', ms=15, label="Logistic Regression")
plt.plot(SAMPLES_PER_CLASS ,FSCORE_NAIVE_BAYES[:,0], linewidth = 3.0, linestyle='--', color ='brown', marker='', ms=15, label="Naive Bayes")
plt.xticks(SAMPLES_PER_CLASS,fontsize=30)
plt.yticks(fontsize=30)
plt.grid(True)
plt.xlabel('Number of training samples per class', fontsize=40)
plt.ylabel('Average F1-score', fontsize=40)
plt.legend(loc="lower right", fontsize=25)
plt.tight_layout()
plt.savefig(RESULT_PATH+ "/F1_low_training_sample_regime_larger_binary_classification.jpg", format='jpg', dpi=300)
plt.show()

# Plotting Standard deviation of F1-score vs. smaples per class
plt.figure(figsize=(15,10))
plt.plot(SAMPLES_PER_CLASS ,STD_FSCORE_NEUROCHAOS[:,0], linewidth = 3.0,  linestyle='solid', color ='r', marker='s',ms=15, label="ChaosFEX+SVM")
plt.plot(SAMPLES_PER_CLASS ,STD_FSCORE_SVM[:,0], linewidth = 3.0, linestyle='--', color ='k', marker='o', ms=15, label="SVM (linear)")
plt.plot(SAMPLES_PER_CLASS ,STD_FSCORE_KNN[:,0], linewidth = 3.0, linestyle='-', color ='g', marker='^', ms=15, label="KNN")
plt.plot(SAMPLES_PER_CLASS ,STD_FSCORE_LOGISTIC_REGRESSION[:,0], linewidth = 3.0, linestyle='-', color ='b', marker='*', ms=10, label="Logistic Regression")
plt.plot(SAMPLES_PER_CLASS ,STD_FSCORE_NAIVE_BAYES[:,0], linewidth = 3.0, linestyle='--', color ='brown', marker='', ms=15, alpha =0.9, label="Naive Bayes")
plt.xticks(SAMPLES_PER_CLASS,fontsize=30)


plt.yticks(fontsize=30)
plt.grid(True)
plt.xlabel('Number of training samples per class', fontsize=40)
plt.ylabel('Standard deviation of F1-scores', fontsize=40)
plt.legend(bbox_to_anchor=[0.55, 0.5], fontsize=25)
#plt.legend(loc="upper right", bbox_to_anchor=[0.5, 0.5], fontsize=18)
plt.tight_layout()
plt.savefig(RESULT_PATH+ "/standard_deviation_low_training_sample_regime_larger_binary_classification.jpg", format='jpg', dpi=300)
plt.show()
